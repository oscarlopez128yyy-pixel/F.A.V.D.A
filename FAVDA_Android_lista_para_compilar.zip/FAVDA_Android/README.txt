F.A.V.D.A. Android - versión mejorada 1.1
========================================

QUÉ INCLUYE
- Aplicación Android basada en Java + WebView.
- Interfaz renovada, adaptable a teléfonos.
- Matemáticas con evaluador aritmético seguro (sin ejecutar código arbitrario).
- Guías de estudio locales.
- Búsqueda de investigaciones.
- Pantalla de tutor IA y conexión configurable a un servidor HTTPS.
- Servidor de ejemplo en Node.js que conecta con OpenAI Responses API.

ABRIR Y COMPILAR ANDROID
1. Descomprime el proyecto.
2. Abre Android Studio y selecciona Open.
3. Selecciona la carpeta FAVDA_Android (la que contiene settings.gradle).
4. Espera la sincronización de Gradle. Requiere Android SDK 35.
5. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará la ubicación del APK.

ACTIVAR EL TUTOR DE INTELIGENCIA ARTIFICIAL
La app Android NO contiene ninguna clave de OpenAI. Por seguridad, la clave debe permanecer en un servidor.

1. En un equipo con Node.js 20 o superior, abre una terminal dentro de servidor-ia.
2. Ejecuta: npm install
3. Copia .env.example como .env.
4. Edita .env y coloca tu clave en OPENAI_API_KEY. No compartas ese archivo ni lo subas a GitHub.
5. Ejecuta: npm start
6. Publica el servidor en un proveedor que permita HTTPS. Para producción, añade autenticación, límites de uso, protección contra abuso y controles de costos.
7. En F.A.V.D.A., abre Tutor IA > Configurar conexión de IA y pega la URL HTTPS completa que termine en /api/chat.

IMPORTANTE SOBRE LA IA
- La conexión requiere una cuenta y una clave de API de OpenAI, además de un servidor desplegado con HTTPS.
- El uso de la API puede generar cargos según el modelo y el consumo. Revisa los límites y el gasto en tu cuenta.
- No pegues la clave secreta en la app Android, HTML, JavaScript ni en este chat.
- El servidor de ejemplo recibe una pregunta por solicitud. Para producción, configura autenticación por usuario, cuotas, moderación y políticas de privacidad.
- La app y el servidor son código fuente; este ZIP no contiene un APK compilado ni un servidor publicado.

PRUEBA SIN IA
Matemáticas, guías básicas e investigaciones funcionan sin configurar el servidor. El Tutor IA muestra cómo configurar la conexión.
