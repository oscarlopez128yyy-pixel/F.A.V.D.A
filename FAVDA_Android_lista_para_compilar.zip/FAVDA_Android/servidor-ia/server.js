import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';

const app = express();
app.use(express.json({ limit: '20kb' }));
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || 'gpt-5.5';
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'FAVDA AI' }));
app.post('/api/chat', async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: 'El servidor todavía no tiene configurada la clave OPENAI_API_KEY.' });
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'Escribe una pregunta.' });
    if (message.length > 6000) return res.status(413).json({ error: 'La pregunta es demasiado larga (máximo 6000 caracteres).' });
    const response = await client.responses.create({
      model,
      instructions: 'Eres el tutor educativo de F.A.V.D.A. Responde en español claro, amable y apropiado para estudiantes. Explica paso a paso, adapta la profundidad al nivel del estudiante, usa ejemplos sencillos y fomenta que la persona razone. Si no sabes algo, dilo. No inventes fuentes, citas ni resultados. No hagas tareas de forma engañosa: ayuda a comprender y elaborar respuestas propias.',
      input: message
    });
    res.json({ reply: response.output_text || 'No pude generar una respuesta. Intenta reformular tu pregunta.' });
  } catch (error) {
    console.error('FAVDA AI error:', error?.message || error);
    res.status(500).json({ error: 'El tutor tuvo un problema al responder. Inténtalo de nuevo más tarde.' });
  }
});
app.listen(port, () => console.log(`F.A.V.D.A. AI listo en el puerto ${port}`));
